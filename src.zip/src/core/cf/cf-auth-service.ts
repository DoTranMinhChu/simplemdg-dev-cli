import { runCommand } from "../process";
import { readCache, rememberCloudFoundryLoginProfile } from "../cache";
import { inferCloudFoundryRegionFromApiEndpoint, readCloudFoundryTarget, setCloudFoundryApiEndpoint } from "../cf";
import { decryptSecret, encryptSecret } from "../db/db-crypto";
import type { TCloudFoundryLoginProfile } from "../types";

export type TCfAuthStatus = {
  cfCliAvailable: boolean;
  hasCachedCredentials: boolean;
  isLoggedIn: boolean;
  cachedUsername?: string;
  lastLoginAt?: string;
  currentTarget?: {
    region?: string;
    apiEndpoint?: string;
    org?: string;
    space?: string;
  };
  authMode: "cached-password" | "none";
  message?: string;
};

export type TCfLoginInput = {
  apiEndpoint: string;
  region?: string;
  username: string;
  password: string;
  remember: boolean;
};

export type TCfLoginResult = {
  success: boolean;
  username?: string;
  apiEndpoint?: string;
  region?: string;
  message?: string;
  error?: string;
};

async function isCfCliAvailable(): Promise<boolean> {
  const result = await runCommand("cf", ["--version"]).catch(() => undefined);
  return Boolean(result && result.exitCode === 0);
}

/**
 * Decrypt a CF profile password that may be either plain-text (legacy) or
 * `enc:…` encrypted by cf-auth-service. Call this before passing a cached
 * password to `cf auth`.
 */
export function decryptCfPassword(stored: string): string {
  return decryptSecret(stored);
}

export async function getCfAuthStatus(): Promise<TCfAuthStatus> {
  const cfCliAvailable = await isCfCliAvailable();

  if (!cfCliAvailable) {
    return {
      cfCliAvailable: false,
      hasCachedCredentials: false,
      isLoggedIn: false,
      authMode: "none",
      message: "CF CLI (cf) is not installed or not on PATH.",
    };
  }

  const cache = await readCache();
  const profilesWithPassword = cache.cloudFoundry.loginProfiles.filter((p) => p.password?.trim());
  const mostRecent = profilesWithPassword[0] ?? cache.cloudFoundry.loginProfiles[0];

  const orgsCheck = await runCommand("cf", ["orgs"]);
  const isLoggedIn = orgsCheck.exitCode === 0;

  const currentTarget = isLoggedIn ? await readCloudFoundryTarget() : undefined;

  return {
    cfCliAvailable: true,
    hasCachedCredentials: profilesWithPassword.length > 0,
    isLoggedIn,
    cachedUsername: mostRecent?.username,
    lastLoginAt: mostRecent?.updatedAt,
    authMode: profilesWithPassword.length > 0 ? "cached-password" : "none",
    currentTarget: currentTarget
      ? {
          apiEndpoint: currentTarget.apiEndpoint,
          org: currentTarget.org,
          space: currentTarget.space,
          region: currentTarget.apiEndpoint
            ? inferCloudFoundryRegionFromApiEndpoint(currentTarget.apiEndpoint)
            : undefined,
        }
      : undefined,
  };
}

export async function loginCfWithPassword(input: TCfLoginInput): Promise<TCfLoginResult> {
  const cfCliAvailable = await isCfCliAvailable();
  if (!cfCliAvailable) {
    return { success: false, error: "CF CLI (cf) is not installed or not on PATH. Install it and restart Studio." };
  }

  const apiResult = await runCommand("cf", ["api", input.apiEndpoint]);
  if (apiResult.exitCode !== 0) {
    const detail = (apiResult.stderr || apiResult.stdout || "").trim();
    return { success: false, error: `Cannot connect to ${input.apiEndpoint}.${detail ? " " + detail : ""}` };
  }

  // Never log the password — pass it directly to cf auth only.
  const authResult = await runCommand("cf", ["auth", input.username, input.password]);
  if (authResult.exitCode !== 0) {
    const raw = authResult.stderr || authResult.stdout || "";
    const safeDetail = raw.replace(new RegExp(input.password.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"), "***").trim();
    return { success: false, error: `Login failed. ${safeDetail || "Invalid username or password."}` };
  }

  const region = input.region || inferCloudFoundryRegionFromApiEndpoint(input.apiEndpoint);

  if (input.remember) {
    const profile: TCloudFoundryLoginProfile = {
      apiEndpoint: input.apiEndpoint,
      org: "",
      username: input.username,
      // Encrypt the password before persisting — never store plain text.
      password: encryptSecret(input.password),
      updatedAt: new Date().toISOString(),
    };
    await rememberCloudFoundryLoginProfile(profile);
  }

  return {
    success: true,
    username: input.username,
    apiEndpoint: input.apiEndpoint,
    region,
    message: `Logged in as ${input.username} to ${region}.`,
  };
}
